﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CleanArch.Sql.Queries
{
 
    [ExcludeFromCodeCoverage]
    public static class UserQueries
    {
        public static string AllUsers => "SELECT * FROM [Users] (NOLOCK)";

        public static string UserByID => "SELECT * FROM [Users] (NOLOCK) WHERE ID =@ID";

        public static string UserLogin => "SELECT * FROM [Users] (NOLOCK) WHERE [UserName] = @UserName and Password =@Password";

        public static string AddUser =>
            @"INSERT INTO [Users] ([Name], [UserName], [Password], [Role], CompanyName ) 
				VALUES (@Name, @UserName, @Password, @Role, @CompanyName )";


        public static string UpdateUser =>
            @"UPDATE [Users] 
            SET [Name] = @Name, 
				[Password] = @Password, 
				[CompanyName] = @CompanyName,
                UserAccess = @UserAccess,
            WHERE ID =@ID";
         public static string DeleteUser => "DELETE FROM [Users] WHERE ID =@ID";
    }
}
