﻿using System.Security.Cryptography;
using System.Text;

namespace CleanArch.Api.Models
{
  
        public class AES
        {
            public static string Decrypt(string pass)
            {
                return Decrypt(pass, string.Empty);
            }

            public static string Decrypt(string pass, string password)
            {
                try
                {
                    RijndaelManaged rijndaelManaged = new RijndaelManaged();
                    rijndaelManaged.Mode = CipherMode.CBC;
                    rijndaelManaged.Padding = PaddingMode.PKCS7;
                    rijndaelManaged.KeySize = 128;
                    rijndaelManaged.BlockSize = 128;
                    byte[] array = Convert.FromBase64String(pass);
                    byte[] bytes = Encoding.UTF8.GetBytes(password);
                    byte[] array2 = new byte[16];
                    int num = bytes.Length;
                    if (num > array2.Length)
                    {
                        num = array2.Length;
                    }

                    Array.Copy(bytes, array2, num);
                    rijndaelManaged.Key = array2;
                    rijndaelManaged.IV = array2;
                    ICryptoTransform cryptoTransform = rijndaelManaged.CreateDecryptor();
                    byte[] bytes2 = cryptoTransform.TransformFinalBlock(array, 0, array.Length);
                    return Encoding.UTF8.GetString(bytes2);
                }
                catch
                {
                    return string.Empty;
                }
            }

            public static string Encrypt(string pass)
            {
                return Encrypt(pass, string.Empty);
            }

            public static string Encrypt(string pass, string password)
            {
                RijndaelManaged rijndaelManaged = new RijndaelManaged();
                rijndaelManaged.Mode = CipherMode.CBC;
                rijndaelManaged.Padding = PaddingMode.PKCS7;
                rijndaelManaged.KeySize = 128;
                rijndaelManaged.BlockSize = 128;
                byte[] bytes = Encoding.UTF8.GetBytes(password);
                byte[] array = new byte[16];
                int num = bytes.Length;
                if (num > array.Length)
                {
                    num = array.Length;
                }

                Array.Copy(bytes, array, num);
                rijndaelManaged.Key = array;
                rijndaelManaged.IV = array;
                ICryptoTransform cryptoTransform = rijndaelManaged.CreateEncryptor();
                byte[] bytes2 = Encoding.UTF8.GetBytes(pass);
                byte[] inArray = cryptoTransform.TransformFinalBlock(bytes2, 0, bytes2.Length);
                return Convert.ToBase64String(inArray);
            }
        }

}
