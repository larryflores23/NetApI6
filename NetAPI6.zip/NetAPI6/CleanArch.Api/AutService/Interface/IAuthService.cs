﻿using CleanArch.Core.Entities;

namespace CleanArch.Api.AutService.Interface
{
    public interface IAuthService
    {
        public Task<UserToken> Login(string UserName, string Password);
        
    }
}
