﻿using CleanArch.Api.AutService.Interface;
using CleanArch.Core.Entities;
using CleanArch.Sql.Queries;
using Microsoft.IdentityModel.Tokens;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Dapper;
using Microsoft.Extensions.Configuration;
using CleanArch.Api.Models;

namespace CleanArch.Api.AutService.Implementation.AuthService
{


        public class AuthService : IAuthService
        {
            private readonly IConfiguration _configuration;
            public AuthService( IConfiguration configuration)
            {
                _configuration = configuration;
            }




        public async Task<UserToken> Login(string UserName, string Password)
            {

            UserToken userToken = new UserToken();
            User? user = null;// await _dbContext.Users.FindAsync(email);

            using (IDbConnection connection = new SqlConnection(_configuration.GetConnectionString("DBConnection")))
            {
                connection.Open();
                user = await connection.QuerySingleOrDefaultAsync<User>(UserQueries.UserLogin, new { UserName = UserName, Password = AES.Encrypt(Password) });
               
            }
      
    

            var tokenHandler = new JwtSecurityTokenHandler();
                var key = Encoding.ASCII.GetBytes(_configuration["JWT:SecretKey"]);

                var tokenDescriptor = new SecurityTokenDescriptor
                {
                    Subject = new ClaimsIdentity(new Claim[]
                    {
                    new Claim(ClaimTypes.Name, "user.UserName"),
                    new Claim(ClaimTypes.GivenName, "user.Name"),
                    new Claim(ClaimTypes.Role, "user.Role")
                    }),
                    IssuedAt = DateTime.UtcNow,
                    Issuer = _configuration["JWT:Issuer"],
                    Audience = _configuration["JWT:Audience"],
                    Expires = DateTime.UtcNow.AddMinutes(30),
                    SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature),
                };

                var token = tokenHandler.CreateToken(tokenDescriptor);
                userToken.Token = tokenHandler.WriteToken(token);
                
                return userToken;
            }

        }
   
}
