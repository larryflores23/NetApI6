﻿using CleanArch.Api.AutService.Implementation.AuthService;
using CleanArch.Api.AutService.Interface;
using CleanArch.Api.Models;
using CleanArch.Application.Interfaces;
using CleanArch.Core.Entities;
using CleanArch.Core.Entities.Request;
using CleanArch.Logging;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json.Linq;
using System.Data;
using System.Data.SqlClient;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace CleanArch.Api.Controllers
{
    public class UserController : BaseApiController
    {
        #region ===[ Private Members ]=============================================================

        private readonly IUnitOfWork _unitOfWork;
        private readonly IConfiguration _configuration;
        private readonly IAuthService _authService;

        #endregion

        #region ===[ Constructor ]=================================================================

        /// <summary>
        /// Initialize ContactController by injecting an object type of IUnitOfWork
        /// </summary>
        public UserController(IUnitOfWork unitOfWork, IConfiguration configuration)
        {
            this._unitOfWork = unitOfWork;
            _configuration = configuration;
 
        }

        #endregion

        #region ===[ Public Methods ]==============================================================

        [Authorize(Roles = "Admin")]
        [Route("GetAll")]
        [HttpGet]
        public async Task<List<User>> GetAll()
        {


           
            var apiResponse = new List<User>();

            try
            {
                var data = await _unitOfWork.Users.GetAllAsync();
                return data.ToList();
            }
            catch (SqlException ex)
            {
                Logger.Instance.Error("SQL Exception:", ex);
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Exception:", ex);
            }

            return apiResponse;
        }

        [Authorize(Roles = "Admin")]
        [HttpGet("{id}")]
        public async Task<User> GetById(int id)
        {

            var apiResponse = new User();

            try
            {
                var data = await _unitOfWork.Users.GetByIdAsync(id);
                return data;
            }
            catch (SqlException ex)
            {
                Logger.Instance.Error("SQL Exception:", ex);
        
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Exception:", ex);
            }

            return apiResponse;
        }

        [Authorize(Roles = "Admin")]
        [HttpPost]
        public async Task<string> Add(UserRequest user)
        {

            try
            {

                var userRequest = new User();
                userRequest.Name = user.Name;
                userRequest.UserName = user.UserName ;
                userRequest.Password = AES.Encrypt(user.Password); 
                userRequest.Role = user.Role;
                userRequest.CompanyName = user.CompanyName;
                userRequest.ID = 0;
               
               var data = await _unitOfWork.Users.AddAsync(userRequest);
                return data;
            }
            catch (SqlException ex)
            {
                Logger.Instance.Error("SQL Exception:", ex);
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Exception:", ex);
     
            }

            return null;
        }


        [Authorize(Roles = "Admin")]
        [HttpPut]
        public async Task<IActionResult> Update(User User)
        {

            try
            {
                User.Password = AES.Encrypt(User.Password);
                await _unitOfWork.Users.UpdateAsync(User);

                return StatusCode(Microsoft.AspNetCore.Http.StatusCodes.Status200OK, "1");
            }
            catch (SqlException ex)
            {
                Logger.Instance.Error("SQL Exception:", ex);
                return StatusCode(Microsoft.AspNetCore.Http.StatusCodes.Status400BadRequest, "0");

            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Exception:", ex);

                return StatusCode(Microsoft.AspNetCore.Http.StatusCodes.Status400BadRequest, "0");
            }

        }

        [Authorize(Roles = "Admin")]
        [HttpDelete("{Id}")]
        public async Task<IActionResult> Delete(int Id)
        {
            try
            {
                await _unitOfWork.Users.DeleteAsync(Id);
                return StatusCode(Microsoft.AspNetCore.Http.StatusCodes.Status200OK, "1");


            }
            catch (SqlException ex)
            {
                Logger.Instance.Error("SQL Exception:", ex);
                return StatusCode(Microsoft.AspNetCore.Http.StatusCodes.Status400BadRequest, "0");
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("SQL Exception:", ex);
                return StatusCode(Microsoft.AspNetCore.Http.StatusCodes.Status400BadRequest, "0");
            }

        }
      
      
        
        #endregion
    }
}