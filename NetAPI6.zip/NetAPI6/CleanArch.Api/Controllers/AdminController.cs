﻿using CleanArch.Core.Entities;
using CleanArch.Sql.Queries;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.Data.SqlClient;
using System.Data;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using CleanArch.Core.Entities.Request;
using CleanArch.Api.Models;
using Dapper;
using CleanArch.Logging;

namespace CleanArch.Api.Controllers
{
    public class AdminController : Controller
    {
        private readonly IConfiguration _configuration;

        public AdminController(IConfiguration configuration)
        {
            _configuration = configuration;

        }

        [Route("CreateAdminAccess")]
        [HttpPost]
        public async Task<string> Add(UserRequest user)
        {
            try
            {

                var userRequest = new User();
                userRequest.Name = user.Name;
                userRequest.UserName = user.UserName;
                userRequest.Password = AES.Encrypt(user.Password);
                userRequest.Role = user.Role;
                userRequest.CompanyName = user.CompanyName;
                userRequest.ID = 0;

                using (IDbConnection connection = new SqlConnection(_configuration.GetConnectionString("DBConnection")))
                {
                    connection.Open();
                    var result = await connection.ExecuteAsync(UserQueries.AddUser, userRequest);
                    return result.ToString();
                }

               
            }
            catch (SqlException ex)
            {
                Logger.Instance.Error("Exception:", ex);
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Exception:", ex);

            }

            return null;
        }

    }
}