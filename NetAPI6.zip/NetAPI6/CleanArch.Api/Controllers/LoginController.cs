﻿using CleanArch.Api.AutService.Interface;
using CleanArch.Api.Models;
using CleanArch.Application.Interfaces;
using CleanArch.Core.Entities;
using CleanArch.Infrastructure.Repository;
using CleanArch.Sql.Queries;
using Dapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json.Linq;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace CleanArch.Api.Controllers
{
    public class LoginController : Controller
    {
      
        private readonly IConfiguration _configuration;

        public LoginController(IConfiguration configuration)
        {
            _configuration = configuration;
            
        }
    
        [Route("Login")]
        [HttpPost]
        public async Task<IActionResult> Login([FromBody] LoginUser user)
        {
            if (String.IsNullOrEmpty(user.UserName))
            {
                return BadRequest(new { message = "Email address needs to entered" });
            }
            else if (String.IsNullOrEmpty(user.Password))
            {
                return BadRequest(new { message = "Password needs to entered" });
            }
            var apiResponse = new UserToken();
            using (IDbConnection connection = new SqlConnection(_configuration.GetConnectionString("DBConnection")))
            {
                connection.Open();
                var result = await connection.QuerySingleOrDefaultAsync<User>(UserQueries.UserLogin, new { UserName = user.UserName, Password = AES.Encrypt( user.Password) });

                if (result == null )
                {
                    return BadRequest(new { message = "User login unsuccessful" });
                }
                else
                {
                    apiResponse.UserName = result.UserName;
                    apiResponse.Role = result.Role;
                    apiResponse.Name = result.Name;
                    apiResponse.CompanyName = result.CompanyName;
                    

                    var tokenHandler = new JwtSecurityTokenHandler();
                    var key = Encoding.ASCII.GetBytes(_configuration["JWT:SecretKey"]);

                    var tokenDescriptor = new SecurityTokenDescriptor
                    {
                        Subject = new ClaimsIdentity(new Claim[]
                        {
                    new Claim(ClaimTypes.Name, result.UserName ),
                    new Claim(ClaimTypes.GivenName,result.CompanyName),
                    new Claim(ClaimTypes.Role, result.Role)
                        }),
                        IssuedAt = DateTime.UtcNow,
                        Issuer = _configuration["JWT:Issuer"],
                        Audience = _configuration["JWT:Audience"],
                        Expires = DateTime.UtcNow.AddMinutes(30),
                        SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature),


                    };

                    var token = tokenHandler.CreateToken(tokenDescriptor);
                    var wToken = tokenHandler.WriteToken(token);
                    apiResponse.Token = tokenHandler.WriteToken(token);
                    return Ok(apiResponse);

                }



            }


       

      
        }



    }
}
